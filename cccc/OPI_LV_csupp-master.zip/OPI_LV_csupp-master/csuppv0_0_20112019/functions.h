#pragma once
int* readFromFile(int* pNumber);
int displayHelp();

float tempCtoF(float temp);
float tempCtoK(float temp);
float tempCtoR(float temp);
float tempCtoDe(float temp);
float tempCtoN(float temp);
float tempCtoRe(float temp);
float tempCtoRo(float temp);
float tempFtoC(float temp);
float tempFtoK(float temp);
float tempFtoR(float temp);
float tempFtoDe(float temp);
float tempFtoN(float temp);
float tempFtoRe(float temp);
float tempFtoRo(float temp);
float tempKtoC(float temp);
float tempKtoF(float temp);
float tempKtoR(float temp);
float tempKtoDe(float temp);
float tempKtoN(float temp);
float tempKtoRe(float temp);
float tempKtoRo(float temp);