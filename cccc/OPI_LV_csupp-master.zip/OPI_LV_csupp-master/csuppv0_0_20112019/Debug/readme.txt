***POMOC***
T0 - Temperatura je optimalna
T1 - Vklopi grelec
T2 - Izklopi grelec

V0 - Vlaznost je optimalna
V1 - Vklopi vlazilec
V2 - Izklopi vlazilec

O0 - Osvetljenost je optimalna
O1 - Prizig luci in odprtje rolet
O2 - Prizig luci
O3 - Izklop luci
O4 - Izklop luci in zatemnitev rolet